<div>
    <h1 class="text-4xl font-semibold">Artikelen die hierop lijken</h1>
    <p class="text-4xl text-gray-400 font-light">Wat vind je hiervan?</p>
    <div class="mt-8 grid grid-cols-4 gap-4">
        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('store.includes.product-small', ['product' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\eindwerk-laravel\resources\views/store/includes/related.blade.php ENDPATH**/ ?>