<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="text-4xl font-semibold mb-8">Mijn bestellingen</h1>

    <div class="grid grid-cols-2 gap-4">
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('orders.includes.order', ['order' => $order], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Je hebt nog geen bestellingen...</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eindwerk-laravel\resources\views/orders/index.blade.php ENDPATH**/ ?>