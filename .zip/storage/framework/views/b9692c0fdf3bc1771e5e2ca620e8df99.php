<?php $__env->startSection('title', 'Shopping cart'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-gray-100 p-4 grid grid-cols-5 gap-4">
        <div class="col-span-3 grid gap-4 content-start">
            <div class="bg-white p-4">
                <h1 class="text-2xl font-semibold">Shopping cart</h1>
                <p class="text-gray-500 text-lg"><?php echo e($products->count()); ?> producten</p>

                <div class="grid gap-4 mt-4">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('cart.includes.cart-item', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php echo $__env->make('cart.includes.delivery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-span-2 grid gap-4 content-start">
            <?php echo $__env->make('cart.includes.discount-code', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="bg-white p-4">
                <h1 class="text-2xl font-semibold">Totaal prijs</h1>
                <table class="w-full">
                    <tr>
                        <td class="py-4">Subtotaal:</td>
                        <td class="py-4 text-right">&euro; <?php echo e($subtotal); ?></td>
                    </tr>
                    <tr>
                        <td class="py-4">Verzending:</td>
                        <td class="py-4 text-right">&euro; <?php echo e($shipping); ?></td>
                    </tr>
                    
                    
                    <tfoot class="border-t border-gray-200">
                        <tr>
                            <td class="py-4 font-semibold">Totaalprijs (inclusief BTW)</td>
                            <td class="py-4 font-semibold text-right">&euro; <?php echo e($total); ?></td>
                        </tr>
                    </tfoot>
                </table>

                <?php if(Auth::user()->cart()->count() > 0): ?>
                    <a href="<?php echo e(route('checkout')); ?>"
                        class="mt-4 block hover:bg-orange-600 bg-orange-500 uppercase text-center font-semibold text-lg cursor-pointer text-white px-4 py-2 w-full">
                        Bestelling plaatsen
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eindwerk-laravel\resources\views/cart/index.blade.php ENDPATH**/ ?>