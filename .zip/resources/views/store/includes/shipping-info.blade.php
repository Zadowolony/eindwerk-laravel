<div class="border border-gray-500 p-4">
    <i class="fa-regular fa-truck"></i>
    <p class="font-semibold mb-4">2-5 werkdagen</p>
    <p class="mb-4">Standaard levering</p>
    <div class="border-t border-gray-500 p-4 -mx-4 -mb-4 flex gap-4 items-center">
        <i class="fa-regular fa-reply"></i>
        <span>100 dagen recht op retour</span>
    </div>
</div>
