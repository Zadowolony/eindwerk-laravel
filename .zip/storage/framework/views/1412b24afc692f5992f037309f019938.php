<a href="<?php echo e(route('favorites.toggle', $product)); ?>" class="group text-2xl bg-white px-4 py-1">

    <?php if(Auth::check()): ?>
        <?php if(Auth::user()->favorites()->where('product_id', $product->id)->count()): ?>
            
            <i class="fas fa-heart text-red-500"></i>
        <?php else: ?>
            
            <i class="far fa-heart"></i>
        <?php endif; ?>
    <?php else: ?>
        
        <i class="far fa-heart"></i>
    <?php endif; ?>
</a>
<?php /**PATH C:\laragon\www\eindwerk-laravel\resources\views/store/includes/favorite.blade.php ENDPATH**/ ?>